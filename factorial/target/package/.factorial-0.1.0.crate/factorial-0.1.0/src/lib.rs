pub fn factorial_func (num:i32) {
    if num == 0 {
    println!("1!");
    }
    else {
        for i in num (
          i= num-1;
          result = num*i;
        )
        println!("{}", result)
    }
}